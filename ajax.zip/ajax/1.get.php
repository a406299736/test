<?php
header('content-type:text/html;charset="utf-8"');
error_reporting(0);
$username=$_GET['username'];
$age=$_GET['age'];
echo"你的明字是：{$username}，年龄是：{$age}";
	