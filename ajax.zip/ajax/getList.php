<?php
header('content-type:text/html;charset="utf-8"');
error_reporting(0);

$arr1=array('lee','meimei','zhangsheng');
$arr2=array('username'=>'lee','age'=>'13');

echo json_encode($arr1);
echo json_encode($arr2);