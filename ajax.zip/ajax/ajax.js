//封裝函數  因為函數中的許多元素是可變的   所以將可變的元素提取出來由一個固定的參數代替
function ajax(method,url,data,success){
	//打开浏览器（创建一个对象 ie7以上兼容）
				var xhr;
				if (window.XMLHttpRequest)
				  {// code for IE7+, Firefox, Chrome, Opera, Safari
				  xhr=new XMLHttpRequest();
				  }
				else
				  {// code for IE6, IE5
				  xhr=new ActiveXObject("Microsoft.XMLHTTP");
				  }
				  
				if(method=='get'&& data){
					url+='?'+data;			
				}
				
				//在地址栏输入地址
				xhr.open(method,url,true);
				if(method=='get'){
					//提交
					xhr.send();	
				}else{
					xhr.setRequestHeader('content-type','application/x-www-form-urlencoded')
					xhr.send(data);	
				}
			
				//等待服务器返回响应
				xhr.onreadystatechange=function(){
					if(xhr.readyState==4){
						if(xhr.status==200){							
						//如果存在的話  執行	
							success&&success(xhr.responseText);
						}else{
							alert('出错了,err:'+xhr.status);
						}
						
					}
				}	
}
